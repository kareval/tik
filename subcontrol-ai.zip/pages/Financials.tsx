import React from 'react';
import { AppState, Role, Status, Action } from '../types';
import { StatusBadge } from '../components/StatusBadge';
import { FileText, Download, CheckCircle, XCircle } from 'lucide-react';

interface FinancialsProps {
  state: AppState;
  dispatch: React.Dispatch<Action>;
}

export const Financials: React.FC<FinancialsProps> = ({ state, dispatch }) => {
  const canApprove = state.currentUserRole === Role.PROJECT_MANAGER;
  const canRatify = state.currentUserRole === Role.DIRECTOR;

  const handleStatusChange = (id: string, newStatus: Status) => {
    dispatch({ type: 'UPDATE_INVOICE_STATUS', payload: { id, status: newStatus } });
  };

  // Group invoices by project for better visibility
  const groupedInvoices = state.invoices.reduce((acc, inv) => {
      const projId = inv.projectId;
      if(!acc[projId]) acc[projId] = [];
      acc[projId].push(inv);
      return acc;
  }, {} as Record<string, typeof state.invoices>);

  return (
    <div className="space-y-8">
       <div>
           <h2 className="text-2xl font-bold text-slate-900">Facturación</h2>
           <p className="text-slate-500 text-sm">Control de facturas mensuales y validación de importes.</p>
        </div>

        <div className="grid gap-6">
            {Object.keys(groupedInvoices).map(projId => {
                const project = state.projects.find(p => p.id === projId);
                const invoices = groupedInvoices[projId];

                return (
                    <div key={projId} className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                        <div className="bg-slate-50 px-6 py-4 border-b border-slate-200 flex justify-between items-center">
                            <div>
                                <h3 className="font-bold text-slate-800">{project?.name}</h3>
                                <p className="text-xs text-slate-500 uppercase tracking-wide">{project?.client}</p>
                            </div>
                            <div className="text-right">
                                <span className="text-xs text-slate-400">Total Facturado</span>
                                <p className="font-bold text-slate-700">
                                    €{invoices.reduce((acc, i) => acc + i.amount, 0).toLocaleString()}
                                </p>
                            </div>
                        </div>
                        <div className="p-0">
                            <table className="w-full text-left text-sm">
                                <thead className="bg-white border-b border-slate-100">
                                    <tr>
                                        <th className="px-6 py-3 font-medium text-slate-500">Periodo</th>
                                        <th className="px-6 py-3 font-medium text-slate-500">Subcontratado</th>
                                        <th className="px-6 py-3 font-medium text-slate-500 text-right">Importe</th>
                                        <th className="px-6 py-3 font-medium text-slate-500 text-center">Estado</th>
                                        <th className="px-6 py-3 font-medium text-slate-500 text-right">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-50">
                                    {invoices.map(inv => {
                                        const sub = state.subcontractors.find(s => s.id === inv.subcontractorId);
                                        return (
                                            <tr key={inv.id} className="hover:bg-slate-50">
                                                <td className="px-6 py-4 font-mono text-slate-600">{inv.period}</td>
                                                <td className="px-6 py-4">{sub?.name}</td>
                                                <td className="px-6 py-4 text-right font-medium">€{inv.amount.toLocaleString()}</td>
                                                <td className="px-6 py-4 text-center"><StatusBadge status={inv.status} /></td>
                                                <td className="px-6 py-4 flex items-center justify-end gap-3">
                                                    <button className="text-slate-400 hover:text-brand-600 transition-colors" title="Ver Factura">
                                                        <FileText size={18} />
                                                    </button>
                                                    
                                                    {/* Approval Logic Similar to Timesheets */}
                                                    {canApprove && inv.status === Status.PENDING && (
                                                        <div className="flex gap-1">
                                                            <button onClick={() => handleStatusChange(inv.id, Status.APPROVED_PM)} className="text-blue-600 hover:bg-blue-50 p-1 rounded"><CheckCircle size={18}/></button>
                                                            <button onClick={() => handleStatusChange(inv.id, Status.REJECTED)} className="text-red-600 hover:bg-red-50 p-1 rounded"><XCircle size={18}/></button>
                                                        </div>
                                                    )}
                                                    {canRatify && inv.status === Status.APPROVED_PM && (
                                                        <div className="flex gap-1">
                                                            <button onClick={() => handleStatusChange(inv.id, Status.RATIFIED_MGR)} className="text-emerald-600 hover:bg-emerald-50 p-1 rounded" title="Ratificar"><CheckCircle size={18}/></button>
                                                            <button onClick={() => handleStatusChange(inv.id, Status.REJECTED)} className="text-red-600 hover:bg-red-50 p-1 rounded"><XCircle size={18}/></button>
                                                        </div>
                                                    )}
                                                </td>
                                            </tr>
                                        )
                                    })}
                                </tbody>
                            </table>
                        </div>
                    </div>
                );
            })}
        </div>
    </div>
  );
};