import React, { useState } from 'react';
import { AppState, Role, Status, TimeLog, Action } from '../types';
import { StatusBadge } from '../components/StatusBadge';
import { CheckCircle, XCircle, Clock, Search, Plus, X } from 'lucide-react';

interface TimeSheetProps {
  state: AppState;
  dispatch: React.Dispatch<Action>;
}

export const TimeSheet: React.FC<TimeSheetProps> = ({ state, dispatch }) => {
  const [filter, setFilter] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  // Modal State
  const [newLogData, setNewLogData] = useState({
    projectId: '',
    date: new Date().toISOString().split('T')[0],
    hours: 8,
    description: ''
  });

  const canApprove = state.currentUserRole === Role.PROJECT_MANAGER;
  const canRatify = state.currentUserRole === Role.DIRECTOR;
  const isSubcontractor = state.currentUserRole === Role.SUBCONTRACTOR;

  const handleStatusChange = (id: string, newStatus: Status) => {
    dispatch({ type: 'UPDATE_TIMELOG_STATUS', payload: { id, status: newStatus } });
  };

  const handleAddLog = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLogData.projectId || !newLogData.description) return;

    // Simulate current subcontractor (hardcoded s1 for demo or s2 if desired, ideally would be dynamic)
    const mockCurrentSubId = 's1'; 

    const newLog: TimeLog = {
      id: Date.now().toString(),
      subcontractorId: mockCurrentSubId,
      projectId: newLogData.projectId,
      date: newLogData.date,
      hours: Number(newLogData.hours),
      description: newLogData.description,
      status: Status.PENDING
    };

    dispatch({ type: 'ADD_TIMELOG', payload: newLog });
    setShowAddModal(false);
    setNewLogData({ projectId: '', date: new Date().toISOString().split('T')[0], hours: 8, description: '' });
  };

  const filteredLogs = state.timeLogs.filter(log => {
     const subName = state.subcontractors.find(s => s.id === log.subcontractorId)?.name.toLowerCase() || '';
     const projName = state.projects.find(p => p.id === log.projectId)?.name.toLowerCase() || '';
     return subName.includes(filter.toLowerCase()) || projName.includes(filter.toLowerCase());
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
           <h2 className="text-2xl font-bold text-slate-900">Control de Horas</h2>
           <p className="text-slate-500 text-sm">Gestiona y aprueba las imputaciones de tiempo.</p>
        </div>
        
        <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
                type="text" 
                placeholder="Buscar proyecto o recurso..." 
                className="pl-10 pr-4 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-brand-500 outline-none w-64"
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
            />
        </div>
      </div>

      {isSubcontractor && (
          <div className="bg-brand-50 border border-brand-200 p-4 rounded-lg flex items-center justify-between">
              <div>
                  <h4 className="font-semibold text-brand-800">Nueva Imputación</h4>
                  <p className="text-sm text-brand-600">Registra tus horas trabajadas para que el Jefe de Proyecto las apruebe.</p>
              </div>
              <button 
                onClick={() => setShowAddModal(true)}
                className="bg-brand-600 hover:bg-brand-700 text-white px-4 py-2 rounded-lg font-medium text-sm transition-colors shadow-md flex items-center gap-2"
              >
                  <Plus size={16} /> Registrar Horas
              </button>
          </div>
      )}

      {/* Add Time Log Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-200">
             <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
               <h3 className="font-bold text-slate-800">Registrar Actividad</h3>
               <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">
                 <X size={20} />
               </button>
             </div>
             <form onSubmit={handleAddLog} className="p-6 space-y-4">
               <div>
                 <label className="block text-sm font-medium text-slate-700 mb-1">Proyecto</label>
                 <select 
                    required
                    className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none"
                    value={newLogData.projectId}
                    onChange={(e) => setNewLogData({...newLogData, projectId: e.target.value})}
                 >
                   <option value="">Seleccionar Proyecto...</option>
                   {state.projects.map(p => (
                     <option key={p.id} value={p.id}>{p.name}</option>
                   ))}
                 </select>
               </div>
               <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Fecha</label>
                    <input 
                      type="date" 
                      required
                      className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none"
                      value={newLogData.date}
                      onChange={(e) => setNewLogData({...newLogData, date: e.target.value})}
                    />
                 </div>
                 <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Horas</label>
                    <input 
                      type="number" 
                      min="0.5" 
                      max="24" 
                      step="0.5"
                      required
                      className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none"
                      value={newLogData.hours}
                      onChange={(e) => setNewLogData({...newLogData, hours: Number(e.target.value)})}
                    />
                 </div>
               </div>
               <div>
                 <label className="block text-sm font-medium text-slate-700 mb-1">Descripción</label>
                 <textarea 
                    required
                    rows={3}
                    placeholder="Detalle de la tarea realizada..."
                    className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none"
                    value={newLogData.description}
                    onChange={(e) => setNewLogData({...newLogData, description: e.target.value})}
                 />
               </div>
               <div className="pt-2">
                 <button type="submit" className="w-full bg-brand-600 hover:bg-brand-700 text-white py-2 rounded-lg font-medium transition-colors">
                   Enviar a Aprobación
                 </button>
               </div>
             </form>
          </div>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-xs uppercase text-slate-500 font-semibold tracking-wider">
                <th className="px-6 py-4">Fecha</th>
                <th className="px-6 py-4">Subcontratado</th>
                <th className="px-6 py-4">Proyecto</th>
                <th className="px-6 py-4">Descripción</th>
                <th className="px-6 py-4 text-center">Horas</th>
                <th className="px-6 py-4">Estado</th>
                {(canApprove || canRatify) && <th className="px-6 py-4 text-right">Acciones</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm text-slate-700">
              {filteredLogs.map((log) => {
                const subcontractor = state.subcontractors.find(s => s.id === log.subcontractorId);
                const project = state.projects.find(p => p.id === log.projectId);
                
                return (
                  <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap text-slate-500">{log.date}</td>
                    <td className="px-6 py-4 font-medium text-slate-900">{subcontractor?.name}</td>
                    <td className="px-6 py-4 text-slate-600">{project?.name}</td>
                    <td className="px-6 py-4 text-slate-600 max-w-xs truncate" title={log.description}>{log.description}</td>
                    <td className="px-6 py-4 text-center font-mono font-medium bg-slate-50/50">{log.hours}h</td>
                    <td className="px-6 py-4">
                      <StatusBadge status={log.status} />
                    </td>
                    {(canApprove || canRatify) && (
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                           {/* PM Flow: Pending -> Approved_PM */}
                           {canApprove && log.status === Status.PENDING && (
                               <>
                                <ActionBtn onClick={() => handleStatusChange(log.id, Status.APPROVED_PM)} type="approve" />
                                <ActionBtn onClick={() => handleStatusChange(log.id, Status.REJECTED)} type="reject" />
                               </>
                           )}
                           
                           {/* Director Flow: Approved_PM -> Ratified_MGR */}
                           {canRatify && log.status === Status.APPROVED_PM && (
                               <>
                                <ActionBtn onClick={() => handleStatusChange(log.id, Status.RATIFIED_MGR)} type="ratify" />
                                <ActionBtn onClick={() => handleStatusChange(log.id, Status.REJECTED)} type="reject" />
                               </>
                           )}
                           
                           {/* If already finalized or not actionable by current role, show nothing or icon */}
                           {((canApprove && log.status !== Status.PENDING) || (canRatify && log.status !== Status.APPROVED_PM)) && (
                               <span className="text-slate-300 text-xs italic">Sin acciones</span>
                           )}
                        </div>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {filteredLogs.length === 0 && (
            <div className="p-12 text-center text-slate-400 flex flex-col items-center">
                <Clock size={48} className="mb-4 opacity-20" />
                <p>No se encontraron registros de tiempo.</p>
            </div>
        )}
      </div>
    </div>
  );
};

const ActionBtn: React.FC<{onClick: () => void, type: 'approve' | 'reject' | 'ratify'}> = ({onClick, type}) => {
    let classes = "p-1.5 rounded hover:bg-opacity-80 transition ";
    let icon;
    let title;

    if (type === 'approve') {
        classes += "bg-blue-100 text-blue-600 hover:bg-blue-200";
        icon = <CheckCircle size={18} />;
        title = "Aprobar (Jefe Proyecto)";
    } else if (type === 'ratify') {
        classes += "bg-emerald-100 text-emerald-600 hover:bg-emerald-200";
        icon = <CheckCircle size={18} />;
        title = "Ratificar (Responsable)";
    } else {
        classes += "bg-red-100 text-red-600 hover:bg-red-200";
        icon = <XCircle size={18} />;
        title = "Rechazar";
    }

    return (
        <button onClick={onClick} className={classes} title={title}>
            {icon}
        </button>
    )
}