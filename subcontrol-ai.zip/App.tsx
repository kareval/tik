import React, { useReducer } from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Dashboard } from './pages/Dashboard';
import { TimeSheet } from './pages/TimeSheet';
import { Financials } from './pages/Financials';
import { Reports } from './pages/Reports';
import { Insights } from './pages/Insights';
import { AppState, Action, Role, Status, Notification } from './types';
import { MOCK_PROJECTS, MOCK_SUBCONTRACTORS, MOCK_TIMELOGS, MOCK_INVOICES, MOCK_NOTIFICATIONS } from './constants';

// Initial State
const initialState: AppState = {
  currentUserRole: Role.PROJECT_MANAGER, // Default role for demo
  projects: MOCK_PROJECTS,
  subcontractors: MOCK_SUBCONTRACTORS,
  timeLogs: MOCK_TIMELOGS,
  invoices: MOCK_INVOICES,
  notifications: MOCK_NOTIFICATIONS,
};

// Helper to create notification
const createNotification = (
  role: Role, 
  msg: string, 
  type: 'info' | 'success' | 'warning' | 'error' = 'info'
): Notification => ({
  id: Date.now().toString() + Math.random().toString().slice(2, 5),
  recipientRole: role,
  message: msg,
  type,
  read: false,
  timestamp: new Date().toISOString()
});

// Reducer for state updates
function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'SET_ROLE':
      return { ...state, currentUserRole: action.payload };
    
    case 'ADD_TIMELOG': {
      // 1. Add the log
      const newLogs = [action.payload, ...state.timeLogs];
      
      // 2. Notify PM
      const subName = state.subcontractors.find(s => s.id === action.payload.subcontractorId)?.name || 'Subcontratado';
      const pmNotification = createNotification(
        Role.PROJECT_MANAGER,
        `${subName} ha enviado ${action.payload.hours}h para aprobación.`,
        'info'
      );

      return {
        ...state,
        timeLogs: newLogs,
        notifications: [pmNotification, ...state.notifications]
      };
    }

    case 'UPDATE_TIMELOG_STATUS': {
      const { id, status } = action.payload;
      const targetLog = state.timeLogs.find(t => t.id === id);
      if (!targetLog) return state;

      const newLogs = state.timeLogs.map(log => 
        log.id === id ? { ...log, status } : log
      );

      const newNotifications: Notification[] = [...state.notifications];

      // LOGIC: Trigger notifications based on status change
      if (status === Status.APPROVED_PM) {
        // Notify Responsible (Director)
        newNotifications.unshift(createNotification(
          Role.DIRECTOR,
          `Horas aprobadas por PM. Listas para ratificación.`,
          'info'
        ));
        // Notify Subcontractor
        newNotifications.unshift(createNotification(
          Role.SUBCONTRACTOR,
          `Tus horas del ${targetLog.date} han sido aprobadas por el Jefe de Proyecto.`,
          'success'
        ));
      } else if (status === Status.RATIFIED_MGR) {
        // Notify Subcontractor
        newNotifications.unshift(createNotification(
          Role.SUBCONTRACTOR,
          `Tus horas del ${targetLog.date} han sido ratificadas por el Responsable.`,
          'success'
        ));
      } else if (status === Status.REJECTED) {
        // Notify Subcontractor
        newNotifications.unshift(createNotification(
          Role.SUBCONTRACTOR,
          `ATENCIÓN: Tus horas del ${targetLog.date} han sido rechazadas.`,
          'error'
        ));
      }

      return {
        ...state,
        timeLogs: newLogs,
        notifications: newNotifications
      };
    }

    case 'UPDATE_INVOICE_STATUS':
      return {
        ...state,
        invoices: state.invoices.map(inv => 
          inv.id === action.payload.id ? { ...inv, status: action.payload.status } : inv
        )
      };

    case 'MARK_NOTIFICATION_READ':
      return {
        ...state,
        notifications: state.notifications.map(n => 
          n.id === action.payload ? { ...n, read: true } : n
        )
      };

    case 'CLEAR_NOTIFICATIONS':
      return {
        ...state,
        notifications: []
      };

    default:
      return state;
  }
}

const App: React.FC = () => {
  const [state, dispatch] = useReducer(reducer, initialState);

  const handleRoleChange = (role: Role) => {
    dispatch({ type: 'SET_ROLE', payload: role });
  };

  return (
    <Router>
      <Layout state={state} dispatch={dispatch} onRoleChange={handleRoleChange}>
        <Routes>
          <Route path="/" element={<Dashboard state={state} />} />
          <Route path="/timesheets" element={<TimeSheet state={state} dispatch={dispatch} />} />
          <Route path="/financials" element={<Financials state={state} dispatch={dispatch} />} />
          <Route path="/reports" element={<Reports state={state} />} />
          <Route path="/insights" element={<Insights state={state} />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    </Router>
  );
};

export default App;