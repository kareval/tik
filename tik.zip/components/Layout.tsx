import React from 'react';
import { NavLink } from 'react-router-dom';
import { MENU_ITEMS } from '../constants';
import { Role, AppState, Action } from '../types';
import { NotificationCenter } from './NotificationCenter';
import { 
  LayoutDashboard, 
  Clock, 
  FileText, 
  BrainCircuit, 
  UserCircle,
  LogOut,
  BarChart3,
  Sun,
  Moon
} from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  state: AppState;
  dispatch: React.Dispatch<Action>;
  onRoleChange: (role: Role) => void;
}

const getIcon = (path: string) => {
  switch (path) {
    case '/': return <LayoutDashboard size={20} />;
    case '/timesheets': return <Clock size={20} />;
    case '/financials': return <FileText size={20} />;
    case '/reports': return <BarChart3 size={20} />;
    case '/insights': return <BrainCircuit size={20} />;
    default: return <LayoutDashboard size={20} />;
  }
};

export const Layout: React.FC<LayoutProps> = ({ children, state, dispatch, onRoleChange }) => {
  const isDark = state.theme === 'dark';

  return (
    <div className="flex h-screen bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 font-sans overflow-hidden transition-colors duration-300">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-white flex flex-col shadow-xl z-20">
        <div className="p-6 border-b border-slate-700">
          <h1 className="text-2xl font-bold tracking-tight bg-gradient-to-r from-blue-400 to-emerald-400 bg-clip-text text-transparent">
            SubControl AI
          </h1>
          <p className="text-slate-400 text-xs mt-1 uppercase tracking-wider">Consulting Partners</p>
        </div>

        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {MENU_ITEMS.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                  isActive
                    ? 'bg-brand-600 text-white shadow-lg shadow-brand-900/50'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`
              }
            >
              {getIcon(item.path)}
              <span className="font-medium">{item.label}</span>
            </NavLink>
          ))}
        </nav>

        {/* User Role Switcher (For Demo Purposes) */}
        <div className="p-4 bg-slate-800 border-t border-slate-700">
          <div className="flex items-center gap-3 mb-3">
            <UserCircle className="text-slate-400" size={24} />
            <div>
              <p className="text-sm font-semibold text-white">Modo Simulación</p>
              <p className="text-xs text-slate-400">Cambiar Rol Activo</p>
            </div>
          </div>
          <select
            value={state.currentUserRole}
            onChange={(e) => onRoleChange(e.target.value as Role)}
            className="w-full bg-slate-900 border border-slate-600 text-slate-200 text-xs rounded p-2 focus:ring-2 focus:ring-brand-500 outline-none"
          >
            <option value={Role.SUBCONTRACTOR}>Subcontratado</option>
            <option value={Role.PROJECT_MANAGER}>Project Manager (PM)</option>
            <option value={Role.DIRECTOR}>Responsable / Dirección</option>
          </select>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-full overflow-hidden relative bg-slate-50 dark:bg-slate-900 transition-colors duration-300">
        <header className="h-16 bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between px-8 shadow-sm z-10">
            <h2 className="text-xl font-semibold text-slate-800 dark:text-white">
                Panel de Control
            </h2>
            <div className="flex items-center gap-4">
                <span className="px-3 py-1 bg-brand-50 dark:bg-brand-900/30 text-brand-600 dark:text-brand-300 text-xs font-bold rounded-full border border-brand-100 dark:border-brand-800 uppercase tracking-wide">
                    {state.currentUserRole.replace('_', ' ')}
                </span>
                
                {/* Theme Toggle */}
                <button 
                  onClick={() => dispatch({ type: 'TOGGLE_THEME' })}
                  className="p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                  title={isDark ? "Cambiar a modo claro" : "Cambiar a modo oscuro"}
                >
                  {isDark ? <Sun size={20} /> : <Moon size={20} />}
                </button>

                {/* Notification Center */}
                <NotificationCenter 
                  notifications={state.notifications} 
                  currentRole={state.currentUserRole}
                  dispatch={dispatch}
                />

                <div className="w-px h-6 bg-slate-200 dark:bg-slate-700 mx-2"></div>

                <button className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200" title="Cerrar sesión (Demo)">
                    <LogOut size={20} />
                </button>
            </div>
        </header>
        <div className="flex-1 overflow-y-auto p-8 scroll-smooth">
          {children}
        </div>
      </main>
    </div>
  );
};