import React, { useReducer, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Dashboard } from './pages/Dashboard';
import { TimeSheet } from './pages/TimeSheet';
import { Financials } from './pages/Financials';
import { Reports } from './pages/Reports';
import { Insights } from './pages/Insights';
import { AppState, Action, Role, Status, Notification } from './types';
import { MOCK_PROJECTS, MOCK_SUBCONTRACTORS, MOCK_TIMELOGS, MOCK_INVOICES, MOCK_NOTIFICATIONS } from './constants';

// Initial State
const initialState: AppState = {
  theme: 'light',
  currentUserRole: Role.PROJECT_MANAGER, 
  projects: MOCK_PROJECTS,
  subcontractors: MOCK_SUBCONTRACTORS,
  timeLogs: MOCK_TIMELOGS,
  invoices: MOCK_INVOICES,
  notifications: MOCK_NOTIFICATIONS,
};

// Helper to create notification
const createNotification = (
  role: Role, 
  msg: string, 
  type: 'info' | 'success' | 'warning' | 'error' = 'info'
): Notification => ({
  id: Date.now().toString() + Math.random().toString().slice(2, 5),
  recipientRole: role,
  message: msg,
  type,
  read: false,
  timestamp: new Date().toISOString()
});

// Reducer for state updates
function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'TOGGLE_THEME':
      return { ...state, theme: state.theme === 'light' ? 'dark' : 'light' };

    case 'SET_ROLE':
      return { ...state, currentUserRole: action.payload };
    
    case 'ADD_TIMELOG': {
      const newLogs = [action.payload, ...state.timeLogs];
      const subName = state.subcontractors.find(s => s.id === action.payload.subcontractorId)?.name || 'Subcontratado';
      const pmNotification = createNotification(
        Role.PROJECT_MANAGER,
        `${subName} ha enviado ${action.payload.hours}h para aprobación.`,
        'info'
      );
      return {
        ...state,
        timeLogs: newLogs,
        notifications: [pmNotification, ...state.notifications]
      };
    }

    case 'BATCH_ADD_TIMELOGS': {
      const newLogs = [...action.payload, ...state.timeLogs];
      const count = action.payload.length;
      const subName = 'Subcontratado'; // In a real app we'd look up the ID
      const pmNotification = createNotification(
        Role.PROJECT_MANAGER,
        `${subName} ha enviado imputaciones para ${count} días/proyectos.`,
        'info'
      );
      return {
        ...state,
        timeLogs: newLogs,
        notifications: [pmNotification, ...state.notifications]
      };
    }

    case 'UPDATE_TIMELOG_STATUS': {
      const { id, status } = action.payload;
      const targetLog = state.timeLogs.find(t => t.id === id);
      if (!targetLog) return state;

      const newLogs = state.timeLogs.map(log => 
        log.id === id ? { ...log, status } : log
      );

      const newNotifications: Notification[] = [...state.notifications];

      if (status === Status.APPROVED_PM) {
        newNotifications.unshift(createNotification(
          Role.DIRECTOR,
          `Horas aprobadas por PM. Listas para ratificación.`,
          'info'
        ));
        newNotifications.unshift(createNotification(
          Role.SUBCONTRACTOR,
          `Tus horas del ${targetLog.date} han sido aprobadas por el Jefe de Proyecto.`,
          'success'
        ));
      } else if (status === Status.RATIFIED_MGR) {
        newNotifications.unshift(createNotification(
          Role.SUBCONTRACTOR,
          `Tus horas del ${targetLog.date} han sido ratificadas por el Responsable.`,
          'success'
        ));
      } else if (status === Status.REJECTED) {
        newNotifications.unshift(createNotification(
          Role.SUBCONTRACTOR,
          `ATENCIÓN: Tus horas del ${targetLog.date} han sido rechazadas.`,
          'error'
        ));
      }

      return {
        ...state,
        timeLogs: newLogs,
        notifications: newNotifications
      };
    }

    case 'UPDATE_INVOICE_STATUS':
      return {
        ...state,
        invoices: state.invoices.map(inv => 
          inv.id === action.payload.id ? { ...inv, status: action.payload.status } : inv
        )
      };
    
    case 'UPDATE_PROJECT_TEAM': {
      const { projectId, subcontractorIds } = action.payload;
      return {
        ...state,
        projects: state.projects.map(p => 
          p.id === projectId 
            ? { ...p, assignedSubcontractorIds: subcontractorIds } 
            : p
        )
      };
    }

    case 'MARK_NOTIFICATION_READ':
      return {
        ...state,
        notifications: state.notifications.map(n => 
          n.id === action.payload ? { ...n, read: true } : n
        )
      };

    case 'CLEAR_NOTIFICATIONS':
      return {
        ...state,
        notifications: []
      };

    default:
      return state;
  }
}

const App: React.FC = () => {
  const [state, dispatch] = useReducer(reducer, initialState);

  const handleRoleChange = (role: Role) => {
    dispatch({ type: 'SET_ROLE', payload: role });
  };

  // Apply dark mode class to html element
  useEffect(() => {
    if (state.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [state.theme]);

  return (
    <Router>
      <Layout state={state} dispatch={dispatch} onRoleChange={handleRoleChange}>
        <Routes>
          <Route path="/" element={<Dashboard state={state} />} />
          <Route path="/timesheets" element={<TimeSheet state={state} dispatch={dispatch} />} />
          <Route path="/financials" element={<Financials state={state} dispatch={dispatch} />} />
          <Route path="/reports" element={<Reports state={state} />} />
          <Route path="/insights" element={<Insights state={state} />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    </Router>
  );
};

export default App;