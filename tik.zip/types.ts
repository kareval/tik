export enum Status {
  PENDING = 'PENDING',       // Recién imputado/subido
  APPROVED_PM = 'APPROVED_PM', // Aprobado por el Jefe de Proyecto
  RATIFIED_MGR = 'RATIFIED_MGR', // Ratificado por Dirección/Gerencia
  REJECTED = 'REJECTED'      // Rechazado
}

export enum Role {
  SUBCONTRACTOR = 'SUBCONTRACTOR',
  PROJECT_MANAGER = 'PROJECT_MANAGER',
  DIRECTOR = 'DIRECTOR'
}

export interface Project {
  id: string;
  name: string;
  client: string;
  budget: number;
  currency: string;
  managerId: string;
  assignedSubcontractorIds: string[]; // List of IDs authorized to log time
}

export interface Subcontractor {
  id: string;
  name: string;
  role: string;
  hourlyRate: number;
  currency: string;
}

export interface TimeLog {
  id: string;
  subcontractorId: string;
  projectId: string;
  date: string; // YYYY-MM-DD
  hours: number;
  description: string;
  status: Status;
  feedback?: string;
}

export interface Invoice {
  id: string;
  subcontractorId: string;
  projectId: string;
  period: string; // e.g., "2023-10"
  amount: number;
  currency: string;
  status: Status;
  fileUrl?: string; // Mock url
}

export interface Notification {
  id: string;
  recipientRole: Role; // Who should see this?
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  read: boolean;
  timestamp: string;
  relatedId?: string; // ID of the timelog or invoice
}

export type Theme = 'light' | 'dark';

export interface AppState {
  theme: Theme;
  currentUserRole: Role;
  projects: Project[];
  subcontractors: Subcontractor[];
  timeLogs: TimeLog[];
  invoices: Invoice[];
  notifications: Notification[];
}

export type Action =
  | { type: 'TOGGLE_THEME' }
  | { type: 'SET_ROLE'; payload: Role }
  | { type: 'UPDATE_TIMELOG_STATUS'; payload: { id: string; status: Status } }
  | { type: 'UPDATE_INVOICE_STATUS'; payload: { id: string; status: Status } }
  | { type: 'ADD_TIMELOG'; payload: TimeLog }
  | { type: 'BATCH_ADD_TIMELOGS'; payload: TimeLog[] }
  | { type: 'ADD_INVOICE'; payload: Invoice }
  | { type: 'MARK_NOTIFICATION_READ'; payload: string }
  | { type: 'CLEAR_NOTIFICATIONS' }
  | { type: 'UPDATE_PROJECT_TEAM'; payload: { projectId: string; subcontractorIds: string[] } };