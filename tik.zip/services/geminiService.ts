import { GoogleGenAI } from "@google/genai";
import { AppState, Status } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// System instruction to act as a financial auditor and project manager assistant
const SYSTEM_INSTRUCTION = `
Eres un asistente experto en gestión de proyectos IT y auditoría financiera. 
Tu objetivo es analizar datos de subcontratación para detectar riesgos, ineficiencias presupuestarias y resumir el estado de los proyectos.
Tus respuestas deben ser profesionales, concisas y orientadas a la toma de decisiones.
Utiliza formato Markdown para mejorar la legibilidad.
`;

export const analyzeProjectHealth = async (state: AppState): Promise<string> => {
  const model = 'gemini-2.5-flash';
  
  // Prepare data context
  const contextData = {
    projects: state.projects,
    pendingHours: state.timeLogs.filter(t => t.status === Status.PENDING).reduce((acc, curr) => acc + curr.hours, 0),
    totalSpent: state.invoices.filter(i => i.status === Status.RATIFIED_MGR).reduce((acc, curr) => acc + curr.amount, 0),
    recentLogs: state.timeLogs.slice(0, 20),
    pendingInvoices: state.invoices.filter(i => i.status !== Status.RATIFIED_MGR)
  };

  const prompt = `
  Analiza el siguiente estado de los proyectos y subcontratados.
  
  Datos crudos (JSON):
  ${JSON.stringify(contextData, null, 2)}
  
  Por favor genera un informe ejecutivo que cubra:
  1. Estado general de costes (Burn rate).
  2. Cuellos de botella en aprobaciones (Horas/Facturas pendientes).
  3. Anomalías detectadas (ej. horas rechazadas, subcontratados con muchas horas pendientes).
  4. Recomendaciones estratégicas para el Director.
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.3, // Low temperature for analytical precision
      }
    });

    return response.text || "No se pudo generar el análisis.";
  } catch (error) {
    console.error("Error calling Gemini:", error);
    return "Error al conectar con el servicio de IA. Verifique su API Key.";
  }
};

export const chatWithData = async (query: string, state: AppState): Promise<string> => {
    const model = 'gemini-2.5-flash';
    
    // Condensed context for chat
    const contextData = {
      projects: state.projects.map(p => ({ id: p.id, name: p.name, budget: p.budget })),
      subcontractors: state.subcontractors.map(s => ({ id: s.id, name: s.name, rate: s.hourlyRate })),
      summary: "Hay varias facturas pendientes de ratificación."
    };
  
    const prompt = `
    Contexto de datos: ${JSON.stringify(contextData)}
    
    Pregunta del usuario: "${query}"
    
    Responde basándote estrictamente en los datos proporcionados o infiriendo lógicamente. Sé breve.
    `;
  
    try {
      const response = await ai.models.generateContent({
        model,
        contents: prompt,
      });
      return response.text || "Sin respuesta.";
    } catch (error) {
        console.error(error);
        return "Lo siento, hubo un error procesando tu consulta.";
    }
};