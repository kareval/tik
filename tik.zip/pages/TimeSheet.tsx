import React, { useState, useMemo } from 'react';
import { AppState, Role, Status, TimeLog, Action, Project } from '../types';
import { StatusBadge } from '../components/StatusBadge';
import { CheckCircle, XCircle, Clock, Search, ChevronLeft, ChevronRight, Calendar, Eye, EyeOff, Save, Grip, Users, X } from 'lucide-react';

interface TimeSheetProps {
  state: AppState;
  dispatch: React.Dispatch<Action>;
}

// Helper to get dates for the week
const getWeekDates = (startDate: Date) => {
  const dates = [];
  const current = new Date(startDate);
  // Adjust to Monday
  const day = current.getDay();
  const diff = current.getDate() - day + (day === 0 ? -6 : 1);
  current.setDate(diff);

  for (let i = 0; i < 7; i++) {
    dates.push(new Date(current));
    current.setDate(current.getDate() + 1);
  }
  return dates;
};

// Check if date is Saturday (6) or Sunday (0)
const isWeekend = (date: Date) => date.getDay() === 0 || date.getDay() === 6;

export const TimeSheet: React.FC<TimeSheetProps> = ({ state, dispatch }) => {
  const [filter, setFilter] = useState('');
  const [currentWeek, setCurrentWeek] = useState(new Date());
  const [showWeekends, setShowWeekends] = useState(false);
  const [isTeamModalOpen, setIsTeamModalOpen] = useState(false);
  
  // Weekly Grid State
  const [gridData, setGridData] = useState<Record<string, Record<string, string>>>({}); // { projectId: { dateStr: hours } }
  
  const canApprove = state.currentUserRole === Role.PROJECT_MANAGER;
  const canRatify = state.currentUserRole === Role.DIRECTOR;
  const isSubcontractor = state.currentUserRole === Role.SUBCONTRACTOR;

  // Mock User Identity for Simulation (in real app, this comes from auth)
  const currentUserId = isSubcontractor ? 's1' : 'pm1'; 

  const weekDates = useMemo(() => getWeekDates(currentWeek), [currentWeek]);
  const dateStrings = weekDates.map(d => d.toISOString().split('T')[0]);

  // For Grid: Get projects assigned to user
  const myProjects = useMemo(() => {
    if (isSubcontractor) {
        return state.projects.filter(p => p.assignedSubcontractorIds.includes(currentUserId));
    }
    return state.projects; // Fallback
  }, [state.projects, isSubcontractor, currentUserId]);

  // Initialize Grid Data with existing logs
  useMemo(() => {
    if (!isSubcontractor) return;
    const initialGrid: Record<string, Record<string, string>> = {};
    
    // Default structure
    myProjects.forEach(p => {
      initialGrid[p.id] = {};
      dateStrings.forEach(ds => {
        // Find existing log
        const log = state.timeLogs.find(l => 
          l.projectId === p.id && 
          l.date === ds && 
          l.subcontractorId === currentUserId
        );
        initialGrid[p.id][ds] = log ? log.hours.toString() : '';
      });
    });
    setGridData(initialGrid);
  }, [weekDates, state.timeLogs, isSubcontractor, myProjects, currentUserId]);

  const handleStatusChange = (id: string, newStatus: Status) => {
    dispatch({ type: 'UPDATE_TIMELOG_STATUS', payload: { id, status: newStatus } });
  };

  const handleGridChange = (projectId: string, dateStr: string, value: string) => {
    setGridData(prev => ({
      ...prev,
      [projectId]: {
        ...prev[projectId],
        [dateStr]: value
      }
    }));
  };

  const saveGrid = () => {
    const newLogs: TimeLog[] = [];
    
    Object.keys(gridData).forEach(projectId => {
      Object.keys(gridData[projectId]).forEach(dateStr => {
        const val = parseFloat(gridData[projectId][dateStr]);
        if (!isNaN(val) && val > 0) {
            // Check if log already exists to avoid duplicates in this simple demo
            const exists = state.timeLogs.some(l => l.projectId === projectId && l.date === dateStr && l.subcontractorId === currentUserId);
            if(!exists) {
                newLogs.push({
                    id: Date.now().toString() + Math.random(),
                    subcontractorId: currentUserId, 
                    projectId,
                    date: dateStr,
                    hours: val,
                    description: 'Imputación semanal',
                    status: Status.PENDING
                });
            }
        }
      });
    });

    if (newLogs.length > 0) {
      dispatch({ type: 'BATCH_ADD_TIMELOGS', payload: newLogs });
      alert('Horas guardadas correctamente.');
    }
  };

  const filteredLogs = state.timeLogs.filter(log => {
     const subName = state.subcontractors.find(s => s.id === log.subcontractorId)?.name.toLowerCase() || '';
     const projName = state.projects.find(p => p.id === log.projectId)?.name.toLowerCase() || '';
     return subName.includes(filter.toLowerCase()) || projName.includes(filter.toLowerCase());
  });

  // --- Subcontractor View (Weekly Grid) ---
  if (isSubcontractor) {
    return (
      <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
         <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
             <div>
                <h2 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Calendar className="text-brand-500" />
                  Mi Hoja de Tiempos
                </h2>
                <p className="text-slate-500 dark:text-slate-400 text-sm">Registra tus horas para la semana actual en tus proyectos asignados.</p>
             </div>
             
             <div className="flex items-center gap-4 bg-white dark:bg-slate-800 p-2 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700">
                <button 
                  onClick={() => setCurrentWeek(new Date(currentWeek.setDate(currentWeek.getDate() - 7)))}
                  className="p-2 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors text-slate-600 dark:text-slate-300"
                >
                  <ChevronLeft size={20} />
                </button>
                <div className="text-center min-w-[140px]">
                   <span className="block text-sm font-semibold text-slate-800 dark:text-white">
                     Semana {weekDates[0].getDate()} - {weekDates[6].getDate()}
                   </span>
                   <span className="text-xs text-slate-500 dark:text-slate-400">
                     {weekDates[0].toLocaleString('es-ES', { month: 'long', year: 'numeric' })}
                   </span>
                </div>
                <button 
                  onClick={() => setCurrentWeek(new Date(currentWeek.setDate(currentWeek.getDate() + 7)))}
                  className="p-2 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors text-slate-600 dark:text-slate-300"
                >
                  <ChevronRight size={20} />
                </button>
             </div>
         </div>

         {myProjects.length === 0 ? (
            <div className="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 p-12 text-center">
                <div className="bg-slate-100 dark:bg-slate-900 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Clock className="text-slate-400" size={32} />
                </div>
                <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">Sin proyectos asignados</h3>
                <p className="text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
                    Actualmente no tienes proyectos asignados para imputar horas. Contacta con tu Project Manager.
                </p>
            </div>
         ) : (
            <div className="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 overflow-hidden">
                <div className="p-4 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center bg-slate-50 dark:bg-slate-900/50">
                    <div className="flex items-center gap-2">
                    <Grip className="text-brand-500" size={18} />
                    <h3 className="font-semibold text-slate-800 dark:text-slate-200">Imputación Rápida</h3>
                    </div>
                    <div className="flex items-center gap-3">
                    <button 
                        onClick={() => setShowWeekends(!showWeekends)}
                        className="flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400 hover:text-brand-600 dark:hover:text-brand-400 transition-colors"
                    >
                        {showWeekends ? <EyeOff size={16} /> : <Eye size={16} />}
                        {showWeekends ? 'Ocultar Fines de Semana' : 'Ver Fines de Semana'}
                    </button>
                    <button 
                        onClick={saveGrid}
                        className="bg-brand-600 hover:bg-brand-700 text-white px-4 py-2 rounded-lg font-medium text-sm shadow-md transition-all flex items-center gap-2"
                    >
                        <Save size={16} /> Guardar Horas
                    </button>
                    </div>
                </div>
                
                <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                    <thead>
                        <tr className="bg-slate-100 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700 text-xs uppercase text-slate-500 dark:text-slate-400 font-semibold tracking-wider">
                            <th className="px-6 py-4 min-w-[200px]">Proyecto Asignado</th>
                            {weekDates.map((date, idx) => {
                                const isWE = isWeekend(date);
                                if (isWE && !showWeekends) return null;
                                const isToday = new Date().toDateString() === date.toDateString();
                                
                                return (
                                <th key={idx} className={`px-2 py-4 text-center min-w-[80px] ${isWE ? 'bg-slate-200/50 dark:bg-slate-800/50' : ''} ${isToday ? 'text-brand-600 dark:text-brand-400' : ''}`}>
                                    <div className="flex flex-col">
                                        <span>{date.toLocaleDateString('es-ES', { weekday: 'short' })}</span>
                                        <span className="text-lg">{date.getDate()}</span>
                                    </div>
                                </th>
                                )
                            })}
                            <th className="px-4 py-4 text-center w-24">Total</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-700 text-sm">
                        {myProjects.map(project => {
                            let rowTotal = 0;
                            return (
                                <tr key={project.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                                <td className="px-6 py-4 font-medium text-slate-800 dark:text-slate-200 border-r border-slate-100 dark:border-slate-700">
                                    {project.name}
                                    <div className="text-xs text-slate-400 font-normal mt-1">{project.client}</div>
                                </td>
                                {weekDates.map((date, idx) => {
                                    const dateStr = date.toISOString().split('T')[0];
                                    const isWE = isWeekend(date);
                                    if (isWE && !showWeekends) return null;
                                    
                                    const val = gridData[project.id]?.[dateStr] || '';
                                    rowTotal += parseFloat(val) || 0;
                                    const existingLog = state.timeLogs.find(l => l.projectId === project.id && l.date === dateStr && l.subcontractorId === currentUserId);
                                    const isLocked = existingLog && (existingLog.status === Status.APPROVED_PM || existingLog.status === Status.RATIFIED_MGR);
                                    
                                    return (
                                        <td key={idx} className={`p-2 border-r border-slate-100 dark:border-slate-800 ${isWE ? 'bg-slate-50 dark:bg-slate-900/40' : ''}`}>
                                            <input 
                                            type="number" 
                                            min="0" 
                                            max="24"
                                            step="0.5"
                                            disabled={!!isLocked}
                                            placeholder="-"
                                            value={val}
                                            onChange={(e) => handleGridChange(project.id, dateStr, e.target.value)}
                                            className={`w-full h-10 text-center rounded-md border text-slate-700 dark:text-slate-200 dark:bg-slate-800 focus:ring-2 focus:ring-brand-500 outline-none transition-all
                                                ${isLocked 
                                                    ? 'bg-emerald-50 dark:bg-emerald-900/20 border-emerald-200 dark:border-emerald-800 cursor-not-allowed' 
                                                    : 'bg-white border-slate-200 dark:border-slate-700'
                                                }
                                                ${val ? 'font-bold' : ''}
                                            `}
                                            />
                                        </td>
                                    )
                                })}
                                <td className="px-4 py-4 text-center font-bold text-slate-900 dark:text-white bg-slate-50 dark:bg-slate-900/30">
                                    {rowTotal > 0 ? rowTotal : '-'}
                                </td>
                                </tr>
                            )
                        })}
                    </tbody>
                    </table>
                </div>
            </div>
         )}
      </div>
    );
  }

  // --- Manager View (List) ---
  return (
    <div className="space-y-6">
      {isTeamModalOpen && (
          <TeamManagementModal 
            state={state} 
            dispatch={dispatch} 
            onClose={() => setIsTeamModalOpen(false)} 
          />
      )}

      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
           <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Aprobación de Horas</h2>
           <p className="text-slate-500 dark:text-slate-400 text-sm">Gestiona y aprueba las imputaciones de tu equipo.</p>
        </div>
        
        <div className="flex gap-3">
            {canApprove && (
                <button 
                    onClick={() => setIsTeamModalOpen(true)}
                    className="flex items-center gap-2 bg-slate-800 dark:bg-slate-700 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-slate-700 dark:hover:bg-slate-600 transition-colors"
                >
                    <Users size={18} /> Gestionar Equipo
                </button>
            )}
            <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input 
                    type="text" 
                    placeholder="Buscar proyecto o recurso..." 
                    className="pl-10 pr-4 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-lg text-sm text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-brand-500 outline-none w-64"
                    value={filter}
                    onChange={(e) => setFilter(e.target.value)}
                />
            </div>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700 text-xs uppercase text-slate-500 dark:text-slate-400 font-semibold tracking-wider">
                <th className="px-6 py-4">Fecha</th>
                <th className="px-6 py-4">Subcontratado</th>
                <th className="px-6 py-4">Proyecto</th>
                <th className="px-6 py-4">Descripción</th>
                <th className="px-6 py-4 text-center">Horas</th>
                <th className="px-6 py-4">Estado</th>
                {(canApprove || canRatify) && <th className="px-6 py-4 text-right">Acciones</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700 text-sm text-slate-700 dark:text-slate-300">
              {filteredLogs.map((log) => {
                const subcontractor = state.subcontractors.find(s => s.id === log.subcontractorId);
                const project = state.projects.find(p => p.id === log.projectId);
                
                return (
                  <tr key={log.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap text-slate-500 dark:text-slate-400">{log.date}</td>
                    <td className="px-6 py-4 font-medium text-slate-900 dark:text-slate-100">{subcontractor?.name}</td>
                    <td className="px-6 py-4 text-slate-600 dark:text-slate-300">{project?.name}</td>
                    <td className="px-6 py-4 text-slate-600 dark:text-slate-400 max-w-xs truncate" title={log.description}>{log.description}</td>
                    <td className="px-6 py-4 text-center font-mono font-medium bg-slate-50/50 dark:bg-slate-800/50 rounded">{log.hours}h</td>
                    <td className="px-6 py-4">
                      <StatusBadge status={log.status} />
                    </td>
                    {(canApprove || canRatify) && (
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                           {canApprove && log.status === Status.PENDING && (
                               <>
                                <ActionBtn onClick={() => handleStatusChange(log.id, Status.APPROVED_PM)} type="approve" />
                                <ActionBtn onClick={() => handleStatusChange(log.id, Status.REJECTED)} type="reject" />
                               </>
                           )}
                           
                           {canRatify && log.status === Status.APPROVED_PM && (
                               <>
                                <ActionBtn onClick={() => handleStatusChange(log.id, Status.RATIFIED_MGR)} type="ratify" />
                                <ActionBtn onClick={() => handleStatusChange(log.id, Status.REJECTED)} type="reject" />
                               </>
                           )}
                           
                           {((canApprove && log.status !== Status.PENDING) || (canRatify && log.status !== Status.APPROVED_PM)) && (
                               <span className="text-slate-300 dark:text-slate-600 text-xs italic">Sin acciones</span>
                           )}
                        </div>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {filteredLogs.length === 0 && (
            <div className="p-12 text-center text-slate-400 dark:text-slate-600 flex flex-col items-center">
                <Clock size={48} className="mb-4 opacity-20" />
                <p>No se encontraron registros de tiempo.</p>
            </div>
        )}
      </div>
    </div>
  );
};

const ActionBtn: React.FC<{onClick: () => void, type: 'approve' | 'reject' | 'ratify'}> = ({onClick, type}) => {
    let classes = "p-1.5 rounded hover:bg-opacity-80 transition ";
    let icon;
    let title;

    if (type === 'approve') {
        classes += "bg-blue-100 text-blue-600 hover:bg-blue-200 dark:bg-blue-900/30 dark:text-blue-400 dark:hover:bg-blue-900/50";
        icon = <CheckCircle size={18} />;
        title = "Aprobar (Jefe Proyecto)";
    } else if (type === 'ratify') {
        classes += "bg-emerald-100 text-emerald-600 hover:bg-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-400 dark:hover:bg-emerald-900/50";
        icon = <CheckCircle size={18} />;
        title = "Ratificar (Responsable)";
    } else {
        classes += "bg-red-100 text-red-600 hover:bg-red-200 dark:bg-red-900/30 dark:text-red-400 dark:hover:bg-red-900/50";
        icon = <XCircle size={18} />;
        title = "Rechazar";
    }

    return (
        <button onClick={onClick} className={classes} title={title}>
            {icon}
        </button>
    )
}

// Modal Component for Team Management
const TeamManagementModal: React.FC<{
  state: AppState; 
  dispatch: React.Dispatch<Action>; 
  onClose: () => void
}> = ({ state, dispatch, onClose }) => {
    const [selectedProjectId, setSelectedProjectId] = useState(state.projects[0]?.id || '');
    const selectedProject = state.projects.find(p => p.id === selectedProjectId);
    
    // Local state for assignments before saving
    const [assignedIds, setAssignedIds] = useState<string[]>([]);

    useMemo(() => {
        if (selectedProject) {
            setAssignedIds(selectedProject.assignedSubcontractorIds || []);
        }
    }, [selectedProjectId, state.projects]);

    const toggleSubcontractor = (subId: string) => {
        setAssignedIds(prev => 
            prev.includes(subId) 
                ? prev.filter(id => id !== subId) 
                : [...prev, subId]
        );
    };

    const handleSave = () => {
        if (selectedProjectId) {
            dispatch({
                type: 'UPDATE_PROJECT_TEAM',
                payload: { projectId: selectedProjectId, subcontractorIds: assignedIds }
            });
            onClose();
        }
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-xl w-full max-w-lg overflow-hidden animate-in zoom-in-95 duration-200">
                <div className="p-6 border-b border-slate-100 dark:border-slate-700 flex justify-between items-center">
                    <h3 className="text-xl font-bold text-slate-800 dark:text-white flex items-center gap-2">
                        <Users size={20} className="text-brand-500"/>
                        Gestionar Equipo
                    </h3>
                    <button onClick={onClose} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors">
                        <X size={24} />
                    </button>
                </div>
                
                <div className="p-6 space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Seleccionar Proyecto</label>
                        <select 
                            value={selectedProjectId} 
                            onChange={(e) => setSelectedProjectId(e.target.value)}
                            className="w-full p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-brand-500 text-slate-800 dark:text-slate-200"
                        >
                            {state.projects.map(p => (
                                <option key={p.id} value={p.id}>{p.name}</option>
                            ))}
                        </select>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                            Personal Asignado
                            <span className="ml-2 text-xs font-normal text-slate-500">
                                ({assignedIds.length} seleccionados)
                            </span>
                        </label>
                        <div className="max-h-60 overflow-y-auto border border-slate-200 dark:border-slate-700 rounded-lg divide-y divide-slate-100 dark:divide-slate-700">
                            {state.subcontractors.map(sub => {
                                const isAssigned = assignedIds.includes(sub.id);
                                return (
                                    <label key={sub.id} className="flex items-center p-3 hover:bg-slate-50 dark:hover:bg-slate-700/50 cursor-pointer transition-colors">
                                        <input 
                                            type="checkbox" 
                                            checked={isAssigned}
                                            onChange={() => toggleSubcontractor(sub.id)}
                                            className="w-5 h-5 text-brand-600 rounded focus:ring-brand-500 border-gray-300"
                                        />
                                        <div className="ml-3">
                                            <p className={`text-sm font-medium ${isAssigned ? 'text-brand-700 dark:text-brand-400' : 'text-slate-700 dark:text-slate-300'}`}>
                                                {sub.name}
                                            </p>
                                            <p className="text-xs text-slate-500 dark:text-slate-400">{sub.role}</p>
                                        </div>
                                    </label>
                                );
                            })}
                        </div>
                    </div>
                </div>

                <div className="p-6 bg-slate-50 dark:bg-slate-900/50 flex justify-end gap-3">
                    <button 
                        onClick={onClose}
                        className="px-4 py-2 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors font-medium text-sm"
                    >
                        Cancelar
                    </button>
                    <button 
                        onClick={handleSave}
                        className="px-6 py-2 bg-brand-600 hover:bg-brand-700 text-white rounded-lg shadow-md hover:shadow-lg transition-all font-medium text-sm"
                    >
                        Guardar Asignaciones
                    </button>
                </div>
            </div>
        </div>
    );
};